var _hTile = '<div class="_hTile "></div>';

var _hBlankTile = '<div class="_hBlankTile element"></div>';

var _hShrine = '<div class="_hShrine element"><div class="_hShrineInner"></div><div class="_hShrineInner 45deg"></div></div>';

var _hTaller = '<div class="_hTaller tile element"><div class="_hTallerInner"></div></div>';

var _hStronger = '<div class="_hStronger tile element"><div class="_hStrongerInner"></div></div>';

var _hSharper = '<div class="_hSharper tile element"><div class="_hSharperInner"></div></div>';

var _hGrass = '<div class="_hGrass element"><div class="pattern"></div><div class="_hGrassInner"><div class="innerPattern"></div></div></div>';

var _hGrassDark = '<div class="_hGrassDark element"><div class="pattern"></div><div class="_hGrassInnerDark"><div class="innerPattern"></div></div></div>';

